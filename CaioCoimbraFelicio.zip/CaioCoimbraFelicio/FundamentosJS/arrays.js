var valores = [7,8,9,10,11]

console.log(valores)
console.log(valores[2], valores[4])
console.log(valores.length)

valores[5] = 20
console.log(valores)

valores.push(90)
valores.push(91)
valores.push(92)

console.log(valores)

valores.pop()
// valores.pop()
// valores.pop()
// valores.pop()
// valores.pop()
// valores.pop()
// valores.pop()

console.log(valores)