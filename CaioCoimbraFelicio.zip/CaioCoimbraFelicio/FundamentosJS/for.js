for(let i = 1; i <= 10; i = i+1){
    console.log(`Contador for = ${i}`)
}
console.log("FIM DO FOR")

let contador = 1
while(contador <= 10){
    console.log(`Contador while = ${contador}`)
    contador++
}
console.log("FIM DO WHILE")