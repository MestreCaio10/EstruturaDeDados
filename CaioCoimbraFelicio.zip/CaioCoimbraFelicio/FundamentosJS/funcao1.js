//funcao sem retorno

function imprimirSoma(a, b){
    console.log(a+b)   
}

imprimirSoma(5, 4)

//função com retorno

function somaRetorno(a, b){
    return a + b
}

console.log(somaRetorno(5, 8))