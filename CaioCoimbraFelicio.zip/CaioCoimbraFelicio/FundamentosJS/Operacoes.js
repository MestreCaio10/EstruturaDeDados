var x = 30
var y = 10
var res1 = x + y
var res2 = x - y
var res3 = x / y
var res4 = x * y

x += y // x = x + y
x -= y

console.log("A soma é: ", res1)
console.log("A subtração é: ", res2)
console.log("A divisão é: ", res3)
console.log("A multiplicaçao é: ", res4)