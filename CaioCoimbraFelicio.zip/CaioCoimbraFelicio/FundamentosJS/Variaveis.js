var nome = "Alexandre" //string
var idade = 44 //integer
var peso = 83.5 //float
var masculino = true //boolean

var nomes = ["Rafael", "Joao", "Jose", "Maria"] // array (vetor)

var cadastro = { //objeto 
    nome: "xandy",
    idade: 44,
    peso: 83.5,
    femino: false
}

console.log(nome)
console.log(idade)

console.log(nomes[2])

console.log("O nome do objeto cadastro é:" , cadastro.nome)